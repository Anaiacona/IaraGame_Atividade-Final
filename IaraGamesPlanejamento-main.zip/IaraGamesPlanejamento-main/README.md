# IaraGamesPlanejamento
Repositório para entrega final IaraGames
Commit realizado por IntelijIdea (Backend)


SRC/main/resources/static -> Back-end e Front-end 
