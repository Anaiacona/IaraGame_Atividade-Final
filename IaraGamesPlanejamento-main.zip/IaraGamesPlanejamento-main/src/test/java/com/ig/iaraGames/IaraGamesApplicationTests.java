package com.ig.iaraGames;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IaraGamesApplicationTests {

	@Test
	void contextLoads() {
	}

}
