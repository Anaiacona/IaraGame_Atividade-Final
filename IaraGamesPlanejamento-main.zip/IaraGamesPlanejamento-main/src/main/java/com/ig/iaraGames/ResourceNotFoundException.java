package com.ig.iaraGames;

public class ResourceNotFoundException {
    public ResourceNotFoundException(String userNotFound) {
    }
}
